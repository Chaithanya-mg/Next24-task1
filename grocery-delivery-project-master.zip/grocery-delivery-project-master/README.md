# Grocery Delivery Project
*Project to scrape data from a grocery website's API and get a text notification when slots become available.*

**Related blog post:** [Finding a grocery delivery slot, the smart way (Towards Data Science)](https://towardsdatascience.com/finding-a-grocery-delivery-slot-the-smart-way-f4f0800c4afe)

<figure>
  <img src=https://miro.medium.com/max/4320/0*99QPnFVWARy4opyN>
  <figcaption>Photo by nrd on Unsplash</figcaption>
</figure>
